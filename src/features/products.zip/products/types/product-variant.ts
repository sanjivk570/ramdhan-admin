export interface ProductVariant {
  uuid: string;

  product_id: number;

  name: string;
  sku: string;

  price: number;
  compare_price: number | null;
  cost_price: number | null;

  stock_quantity: number;
  low_stock_threshold: number;

  is_default: boolean;
  is_active: boolean;

  sort_order: number;

  attribute_values?: AttributeValue[];

  created_at: string;
  updated_at: string;
}

export interface AttributeValue {
  uuid: string;
  value: string;
  display_value?: string;
  attribute_id: number;
  attribute?: {
    uuid: string;
    name: string;
  };
}

export interface CreateProductVariantPayload {
  name: string;
  sku: string;

  price: number;
  compare_price?: number | null;
  cost_price?: number | null;

  stock_quantity?: number;
  low_stock_threshold?: number;

  is_default?: boolean;
  is_active?: boolean;

  sort_order?: number;

  attribute_values: string[];
}

export type UpdateProductVariantPayload = CreateProductVariantPayload;
