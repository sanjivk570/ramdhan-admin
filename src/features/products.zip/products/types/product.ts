export interface ProductCategory {
  uuid: string;
  name: string;
  slug?: string;
}

export interface ProductUnit {
  id: number;
  uuid: string;
  name: string;
  code: string;
  symbol: string;
}

export interface ProductTaxClass {
  id: number;
  uuid: string;
  name: string;
  code: string;
}

export interface ProductMedia {
  uuid: string;
  original_name: string;
  file_name: string;
  url: string | null;
  path: string;
  disk: string;
  mime_type: string;
  size: number;
  size_kb: number;
  title: string | null;
  alt_text: string | null;
  description: string | null;
  type: string;
  sort_order: number;
  is_primary: boolean;
  collection: string;
}

export interface Product {
  uuid: string;
  name: string;
  slug: string;
  sku: string;

  unit_id: number | null;
  tax_class_id: number | null;

  description: string | null;
  short_description: string | null;

  price: number;
  compare_price: number | null;
  cost_price: number | null;

  stock_quantity: number;
  low_stock_threshold: number;

  is_active: boolean;
  is_featured: boolean;

  sort_order: number;

  categories?: ProductCategory[];
  images?: ProductMedia[];

  unit?: ProductUnit;
  tax_class?: ProductTaxClass;

  created_at: string;
  updated_at: string;
}

export interface ProductListParams {
  page?: number;
  per_page?: number;

  search?: string;

  "filters[category]"?: string;
  "filters[unit_id]"?: number;
  "filters[tax_class_id]"?: number;
  "filters[is_active]"?: boolean;
  "filters[is_featured]"?: boolean;

  "filters[min_price]"?: number;
  "filters[max_price]"?: number;

  sort_by?: string;
  sort_order?: "asc" | "desc";
}

export interface CreateProductPayload {
  name: string;
  slug: string;
  sku: string;

  unit_id: number;
  tax_class_id: number;

  description?: string;
  short_description?: string;

  price: number;
  compare_price?: number | null;
  cost_price?: number | null;

  stock_quantity?: number;
  low_stock_threshold?: number;

  is_active?: boolean;
  is_featured?: boolean;

  sort_order?: number;

  categories?: string[];
}

export type UpdateProductPayload = CreateProductPayload;
