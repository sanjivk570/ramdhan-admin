import api from "@/api/axios";
import type {
  Product,
  ProductListParams,
  CreateProductPayload,
  UpdateProductPayload,
} from "../types/product";

const BASE_URL = "/api/v1/products";

const productService = {
  async list(params?: ProductListParams) {
    const response = await api.get(BASE_URL, {
      params,
    });

    return response.data;
  },

  async get(uuid: string) {
    const response = await api.get<Product>(`${BASE_URL}/${uuid}`);

    return response.data;
  },

  async create(payload: CreateProductPayload) {
    const response = await api.post(BASE_URL, payload);

    return response.data;
  },

  async update(uuid: string, payload: UpdateProductPayload) {
    const response = await api.put(`${BASE_URL}/${uuid}`, payload);

    return response.data;
  },

  async updateStatus(uuid: string, status: boolean) {
    const response = await api.patch(`${BASE_URL}/${uuid}/status`, {
      status,
    });

    return response.data;
  },

  async delete(uuid: string) {
    const response = await api.delete(`${BASE_URL}/${uuid}`);

    return response.data;
  },

  async restore(uuid: string) {
    const response = await api.post(`${BASE_URL}/${uuid}/restore`);

    return response.data;
  },

  async forceDelete(uuid: string) {
    const response = await api.delete(`${BASE_URL}/${uuid}/force`);

    return response.data;
  },
};

export default productService;
